// Wait for the DOM to be fully loaded
document.addEventListener("DOMContentLoaded", () => {
    // ===== LOGIN/SIGNUP FUNCTIONALITY =====
  
    // Show login or signup tab
    function showTab(tabName) {
      // Hide all tabs
      document.querySelectorAll(".form-content").forEach((tab) => {
        tab.classList.remove("active")
      })
  
      // Remove active class from all tab buttons
      document.querySelectorAll(".tab-btn").forEach((btn) => {
        btn.classList.remove("active")
      })
  
      // Show the selected tab
      document.getElementById(tabName).classList.add("active")
  
      // Add active class to the clicked button
      document.querySelector(`.tab-btn[onclick="showTab('${tabName}')"]`).classList.add("active")
    }
  
    // Make showTab function globally accessible
    window.showTab = showTab
  
    // Handle login form submission
    const loginForm = document.getElementById("loginForm")
    if (loginForm) {
      loginForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        // In a real application, you would validate credentials here
        // For this demo, we'll just redirect to the home page
        window.location.href = "home.html"
      })
    }
  
    // Handle signup form submission
    const signupForm = document.getElementById("signupForm")
    if (signupForm) {
      signupForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        // In a real application, you would create a new account here
        // For this demo, we'll just redirect to the home page
        window.location.href = "home.html"
      })
    }
  
    // ===== NAVIGATION FUNCTIONALITY =====
  
    // Toggle mobile navigation
    const navToggle = document.getElementById("navToggle")
    const mainNav = document.getElementById("mainNav")
  
    if (navToggle && mainNav) {
      navToggle.addEventListener("click", () => {
        mainNav.classList.toggle("active")
  
        // Toggle hamburger/close icon
        const spans = navToggle.querySelectorAll("span")
        if (mainNav.classList.contains("active")) {
          spans[0].style.transform = "rotate(45deg) translate(5px, 5px)"
          spans[1].style.opacity = "0"
          spans[2].style.transform = "rotate(-45deg) translate(5px, -5px)"
        } else {
          spans[0].style.transform = "none"
          spans[1].style.opacity = "1"
          spans[2].style.transform = "none"
        }
      })
    }
  
    // Handle navigation clicks
    const navLinks = document.querySelectorAll("nav ul li a")
    const sections = document.querySelectorAll(".section")
  
    if (navLinks.length > 0 && sections.length > 0) {
      navLinks.forEach((link) => {
        link.addEventListener("click", function (e) {
          // Don't handle logout link here
          if (this.id === "logoutBtn") return
  
          e.preventDefault()
  
          // Remove active class from all links
          navLinks.forEach((link) => link.classList.remove("active"))
  
          // Add active class to clicked link
          this.classList.add("active")
  
          // Hide all sections
          sections.forEach((section) => section.classList.remove("active"))
  
          // Show the corresponding section
          const targetId = this.getAttribute("href").substring(1)
          document.getElementById(targetId).classList.add("active")
  
          // Close mobile navigation if open
          if (mainNav && mainNav.classList.contains("active")) {
            mainNav.classList.remove("active")
  
            // Reset hamburger icon
            if (navToggle) {
              const spans = navToggle.querySelectorAll("span")
              spans[0].style.transform = "none"
              spans[1].style.opacity = "1"
              spans[2].style.transform = "none"
            }
          }
  
          // Scroll to top of the section
          window.scrollTo({
            top: 0,
            behavior: "smooth",
          })
        })
      })
    }
  
    // Handle logout button click
    const logoutBtn = document.getElementById("logoutBtn")
    if (logoutBtn) {
      logoutBtn.addEventListener("click", (e) => {
        e.preventDefault()
  
        // In a real application, you would handle logout logic here
        // For this demo, we'll just redirect to the login page
        window.location.href = "index.html"
      })
    }
  
    // ===== ANNOUNCEMENTS FUNCTIONALITY =====
  
    // Show/hide announcement form
    const newAnnouncementBtn = document.getElementById("newAnnouncementBtn")
    const announcementForm = document.getElementById("announcementForm")
    const cancelAnnouncementBtn = document.getElementById("cancelAnnouncementBtn")
  
    if (newAnnouncementBtn && announcementForm) {
      newAnnouncementBtn.addEventListener("click", function () {
        announcementForm.classList.remove("hidden")
        this.classList.add("hidden")
      })
    }
  
    if (cancelAnnouncementBtn && announcementForm && newAnnouncementBtn) {
      cancelAnnouncementBtn.addEventListener("click", () => {
        announcementForm.classList.add("hidden")
        newAnnouncementBtn.classList.remove("hidden")
      })
    }
  
    // Handle announcement form submission
    const createAnnouncementForm = document.getElementById("createAnnouncementForm")
    if (createAnnouncementForm) {
      createAnnouncementForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        // Get form values
        const title = document.getElementById("announcementTitle").value
        const content = document.getElementById("announcementContent").value
  
        // Create new announcement card
        const announcementCard = document.createElement("div")
        announcementCard.className = "announcement-card"
  
        // Get current date
        const now = new Date()
        const dateStr = now.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })
  
        // Create announcement HTML
        announcementCard.innerHTML = `
                  <div class="announcement-header">
                      <h3>${title}</h3>
                      <span class="date">${dateStr}</span>
                  </div>
                  <div class="announcement-body">
                      <p>${content}</p>
                      <button class="delete-btn">Delete</button>
                  </div>
              `
  
        // Add image if selected
        const imageInput = document.getElementById("announcementImage")
        if (imageInput.files.length > 0) {
          // In a real application, you would upload the image to a server
          // For this demo, we'll just add a placeholder
          const imgElement = document.createElement("img")
          imgElement.src = "https://via.placeholder.com/500x300?text=Announcement+Image"
          imgElement.alt = "Announcement Image"
          announcementCard.querySelector(".announcement-body").appendChild(imgElement)
        }
  
        // Add the new announcement to the top of the list
        const announcementsContainer = document.querySelector(".announcements-container")
        announcementsContainer.insertBefore(announcementCard, announcementsContainer.firstChild)
  
        // Reset form and hide it
        createAnnouncementForm.reset()
        announcementForm.classList.add("hidden")
        newAnnouncementBtn.classList.remove("hidden")
      })
    }
  
    // ===== CONTACT FORM FUNCTIONALITY =====
  
    // Handle contact form submission
    const contactForm = document.getElementById("contactForm")
    if (contactForm) {
      contactForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        // In a real application, you would send the form data to a server
        // For this demo, we'll just show an alert
        alert("Thank you for your message! We will get back to you soon.")
        contactForm.reset()
      })
    }
  })
    // ===== DELETE ANNOUNCEMENTS FUNCTIONALITY =====
    document.addEventListener("click", function(e) {
      if (e.target.classList.contains("delete-btn")) {
        const card = e.target.closest(".announcement-card")
        if (card) card.remove()
      }
    })
  